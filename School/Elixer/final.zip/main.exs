defmodule Present do
  defstruct whofrom: "", whofor: "", price: 0.0, description: ""

  def new(whofor, whofrom, description, price \\ 0.0) do
    %Present{whofor: whofor, whofrom: whofrom, description: description, price: price}
  end

  def print_present(%Present{} = p) do
    IO.puts("A #{p.description} for #{p.whofor} from #{p.whofrom}")
  end
end

defmodule Listy do

  def double(numbers) do
    numbers
    |> Enum.map(fn n -> n * 2 end)
  end

  def large(numbers) do
    numbers
    |> double()
    |> Enum.filter(fn t -> t > 100.0 end)
  end

  def average(numbers) do
    sum =
      numbers
      |> Enum.reduce(0, fn n, acc -> acc + n end)
    
    sum / length(numbers)
  end

  def print_list([]), do: IO.puts("")
  def print_list([first | rest]) do
    IO.write("#{first} ")
    print_list(rest)
  end

  def each([], _), do: nil
  def each([first | rest], f) do
    f.(first)
    each(rest, f)
  end
end


# tuple
animal = {"bear", 300, :mammal}
{name, weight, kind} = animal
IO.puts("#{name}, a #{kind}, weighs #{weight}")

# list
temps = [98.6, 77.5, 33.4, 67.0, 32.0]
[first | _rest] = temps
IO.puts("Today it is #{first}")

[_, second | _] = temps
IO.puts("Tomorrow it will be #{second}")

Listy.print_list(temps)

#fourth = Enum.at(temps, 3)
Listy.each(temps, fn t -> IO.write("#{t} ") end)
IO.puts("")

new_temps = Listy.double(temps)
IO.inspect(new_temps)

temps |> Listy.large() |> IO.inspect()

IO.puts("Average temp is #{Listy.average(temps)}")

# map
stuff = %{contents: "cookies", weight: 8.7, price: 9.99}
IO.puts("I have some stuff: #{stuff.contents}")

your_stuff = %{stuff | contents: "doughnuts"}
IO.puts("You have some stuff: #{your_stuff.contents}")

ep = Present.new("Eleanor", "Santa", "case")

Present.print_present(ep)